# Project Setup:

## 1. Unzip the Project Files

## 2. Install pipenv if not installed already

pip install pipenv

## 3. Set up the Virtual Environment

-Go to the folder where the pipfile is located (LittleLemonAPI). 

-Use the command: pipenv --python 3.8  (Replace 3.8 with your preferred Python version). 

-Install the dependencies for the project: pipenv install (Note: you may need to delete pipfile.lock if having compatibility issues)

-Install django within the virtual environment: pipenv install django.

## 4. Activate the Virtual Environment

pipenv shell

## 5. Proceed to test the application!

* python manage.py makemigrations
* python manage.py migrate
* python manage.py createsuperuser
* python manage.py runserver
* use insomnia or other tools
* etc.

**Note: The supersuser I created for testing is called: admin and the password is also admin. Feel free to use it or create your own. Then, login into http://localhost:8000/admin.


       